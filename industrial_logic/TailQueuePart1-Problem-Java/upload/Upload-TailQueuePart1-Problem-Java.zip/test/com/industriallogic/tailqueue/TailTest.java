/// ***************************************************************************
/// Copyright (c) 2009, Industrial Logic, Inc., All Rights Reserved.
///
/// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
/// used by students during Industrial Logic's workshops or by individuals
/// who are being coached by Industrial Logic on a project.
///
/// This code may NOT be copied or used for any other purpose without the prior
/// written consent of Industrial Logic, Inc.
/// ****************************************************************************

package com.industriallogic.tailqueue;

import java.util.Calendar;

import junit.framework.TestCase;

public class TailTest extends TestCase {

	private Tail firstTail, secondTail, thirdTail, fourthTail, fifthTail, sixthTail, seventhTail, eighthTail;
	
	@Override
	protected void setUp() throws Exception {
		Calendar currentTime = Calendar.getInstance();
		firstTail 	= new Tail(01, Tail.URGENT, currentTime);
		secondTail 	= new Tail(01, Tail.URGENT, currentTime);
		thirdTail 	= new Tail(03, Tail.URGENT, currentTime);
		
		Calendar earlier = Calendar.getInstance();
	    earlier.add(Calendar.SECOND, -10);
	    fourthTail  = new Tail(04, Tail.URGENT, earlier);
	    
	    Calendar later = Calendar.getInstance();
	    later.add(Calendar.SECOND, 10);
	    fifthTail   = new Tail(05, Tail.URGENT, later);
	    
	    sixthTail 	= new Tail(06, Tail.IMPORTANT, currentTime);
	    seventhTail = new Tail(07, Tail.REQUESTING, currentTime);
	    eighthTail 	= new Tail(13, Tail.DISMISSED, currentTime);
	}
	
	public void testIfEqual() {
		assertEquals("It should be 0 for equal id's.", 0, firstTail.compareTo(firstTail));
	}
	
	public void testSameIDs() {
		assertEquals("It should be 0 for equal id's.", 0, firstTail.compareTo(secondTail));
		assertEquals("It should be 0 for equal id's.", 0, secondTail.compareTo(firstTail));
	}
	
	public void testDifferentIDs() {
		assertEquals("It should be 0 for equal id's.", -1, firstTail.compareTo(thirdTail));
		assertEquals("It should be 0 for equal id's.", 1, thirdTail.compareTo(firstTail));
	}
	
	public void testDifferentIDsWithEarlierTime() {
		assertEquals("It should be 0 for equal id's.", 1, firstTail.compareTo(fourthTail));
		assertEquals("It should be 0 for equal id's.", -1, fourthTail.compareTo(firstTail));
	}

	public void testDifferentIDsWithLaterTime() {
		assertEquals("It should be 0 for equal id's.", -1, firstTail.compareTo(fifthTail));
		assertEquals("It should be 0 for equal id's.", 1, fifthTail.compareTo(firstTail));
	}
	
	public void testDifferentIDsWithHigherPriority() {
		assertEquals("It should be 0 for equal id's.", -1, firstTail.compareTo(sixthTail));
		assertEquals("It should be 0 for equal id's.", -1, firstTail.compareTo(seventhTail));
		assertEquals("It should be 0 for equal id's.", -1, firstTail.compareTo(eighthTail));
		assertEquals("It should be 0 for equal id's.", -1, sixthTail.compareTo(seventhTail));
		assertEquals("It should be 0 for equal id's.", -1, sixthTail.compareTo(eighthTail));
		assertEquals("It should be 0 for equal id's.", -1, seventhTail.compareTo(eighthTail));
	}
	
	public void testDifferentIDsWithLowerPriority() {
		assertEquals("It should be 0 for equal id's.", 1, eighthTail.compareTo(firstTail));
		assertEquals("It should be 0 for equal id's.", 1, eighthTail.compareTo(sixthTail));
		assertEquals("It should be 0 for equal id's.", 1, eighthTail.compareTo(seventhTail));
		assertEquals("It should be 0 for equal id's.", 1, seventhTail.compareTo(firstTail));
		assertEquals("It should be 0 for equal id's.", 1, seventhTail.compareTo(sixthTail));
		assertEquals("It should be 0 for equal id's.", 1, sixthTail.compareTo(firstTail));
	}


}
