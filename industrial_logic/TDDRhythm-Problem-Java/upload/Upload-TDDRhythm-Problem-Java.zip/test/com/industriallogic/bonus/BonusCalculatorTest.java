/// ***************************************************************************
/// Copyright (c) 2009, Industrial Logic, Inc., All Rights Reserved.
///
/// This code is the exclusive property of Industrial Logic, Inc. It may ONLY be
/// used by students during Industrial Logic's workshops or by individuals
/// who are being coached by Industrial Logic on a project.
///
/// This code may NOT be copied or used for any other purpose without the prior
/// written consent of Industrial Logic, Inc.
/// ****************************************************************************

package com.industriallogic.bonus;

import junit.framework.Assert;
import org.junit.Test;;

public class BonusCalculatorTest{
	
	@Test
	public void testIndividualQuotaNotExceeded() {
		Assert.assertEquals("Sales Exceeded Individual Quota.", 0d, BonusCalculator.individualBonus(900, 1000, 10, 10));
	}
	
	@Test
	public void testIndividualQuotaExceeded() {
		double bonus  = (1100 - 1000) * 10 / 100.0 * (1.0 - (10 / 100.0));
		Assert.assertEquals("Sales Exceeded Individual Quota.", bonus, BonusCalculator.individualBonus(1100, 1000, 10, 10));
	}
	
	@Test
	public void testTeamQuotaNotExceeded() {
		Assert.assertEquals("Sales Exceeded Individual Quota.", 0d, BonusCalculator.teamBonus(900, 1000, 10, 4));
	}
	
	@Test
	public void testTeamQuotaExceeded() {
		double bonus  = ((1100 - 1000) * 10 / 100.0) / 4;
		Assert.assertEquals("Sales Exceeded Individual Quota.", bonus, BonusCalculator.teamBonus(1100, 1000, 10, 4));
	}
	
}
	
